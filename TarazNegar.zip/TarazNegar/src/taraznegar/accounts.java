/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author negar
 */
public class accounts {
     JPanel accPane;
    JTabbedPane tp;
    JTable table;
    JButton addBtn;
    JButton deleteBtn;
    
    
    private static String[] header = {"ملاحظات","اقلام","وضعیت حساب","ماهیت حساب","نوع حساب","مرکز هزینه","گرووه حساب", "نام", "کد"};
    private static  DefaultTableModel dtm = new DefaultTableModel (null, header) {

        @Override
        public Class<?> getColumnClass(int col) {
            return getValueAt(0, col).getClass();
        }
    };
    public accounts()  {
         try {
                Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB", "root", "1234");
            java.sql.Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from myAccs order by code");
            while(rs.next())
                dtm.addRow(new Object[]{rs.getString(9),rs.getString(8),rs.getString(7),rs.getString(6)
                        ,rs.getString(5),rs.getString(4),rs.getString(3),rs.getString(2),rs.getString(1)});
            con.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        ImageIcon icon1 = new ImageIcon("/home/negar/Downloads/icon.png");
        Image img = icon1.getImage() ;  
        Image newimg = img.getScaledInstance( 5, 5,  java.awt.Image.SCALE_SMOOTH ) ;  
        icon1 = new ImageIcon( newimg );
        tp=new JTabbedPane();
        tp.setBounds(0, 0, 1850, 800);
        addBtn=new JButton(icon1);
        addBtn.setText("افزودن");
        deleteBtn=new JButton("delete");
        accPane=new JPanel();
        accPane.setLayout(null);
        accPane.add(tp);      
        table=new JTable(dtm);
    
        addBtn.setBounds(30,850,100,50);
        deleteBtn.setBounds(200,850,100,50);
        accPane.add(addBtn);
        accPane.add(deleteBtn);
        table.setBounds(50,50,200,300);
        JScrollPane sp=new JScrollPane(table);
        sp.setBounds(0, 50, 500, 500);
       
        addBtn.addActionListener(new ActionListener(){
             @Override
            public void actionPerformed(ActionEvent actionEvent) {
                 
                     addAccount addac=new addAccount();
                    
            }
        });
        deleteBtn.addActionListener(new ActionListener(){
             @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int i =table.getSelectedRow();
                String code=(String) dtm.getValueAt(i, 8);
                
                 System.out.println(code);
                dtm.removeRow(i);
                     try 
     {  
        Class.forName("com.mysql.jdbc.Driver");
            Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");

        PreparedStatement st = con.prepareStatement("DELETE FROM myAccs WHERE code = " + code + ";");
        
        st.executeUpdate(); 
        con.close();
     }
     catch(Exception e)
     {
         System.out.println(e);
     }
            }
        });
       
       tp.add(sp);
       //tp.add(addBtn);

        
    }

    static void addRows(acc ac)  {
       // addAccount addac=new addAccount();
        System.out.println("addiiiing");
         //acc ac=new acc();
         //ac=addac.test();
        


          if(ac.code != null){
              
              if(ac.accMatter==null)
                  ac.accMatter="بدهکار/بستانکار";
              if(ac.accStatus==null)
                  ac.accStatus="هیچکدام";
              if(ac.accType== null)
                  ac.accType="دایم";
              if(ac.attentions== null)
                  ac.attentions=" ";
              if(ac.items== null)
                  ac.items="اقلام سود و زیانی نمیباشند";
              if(ac.center== null)
                  ac.center=" ";
              
              
        System.out.println(ac.code);
        System.out.println(ac.name);
        System.out.println(ac.accountGP);
        System.out.println(ac.center);
        System.out.println(ac.accType);
        System.out.println(ac.accMatter);
        System.out.println(ac.accStatus);
        System.out.println(ac.items);
        System.out.println(ac.attentions);
                dtm.addRow(new Object[]{
                     ac.attentions,ac.items,ac.accStatus,ac.accMatter,ac.accType
                        ,ac.center,ac.accountGP,ac.name,ac.code });



                
          try {
                Class.forName("com.mysql.jdbc.Driver");
            Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
           String insertSQL = "INSERT INTO myAccs (code,name,accountGP,center,accType,accMatter,accStatus,items,attentions) VALUES (?,?,?,?,?,?,?,?,?)";
           PreparedStatement preparedStatement = con.prepareStatement(insertSQL);
           preparedStatement.setString(1, ac.code);
           preparedStatement.setString(2, ac.name);
           preparedStatement.setString(3, ac.accountGP);
           preparedStatement.setString(4, ac.center);
           preparedStatement.setString(5, ac.accType);
           preparedStatement.setString(6, ac.accMatter);
           preparedStatement.setString(7, ac.accStatus);
           preparedStatement.setString(8, ac.items);
           preparedStatement.setString(9, ac.attentions);
              System.out.println("add to db");
           preparedStatement.executeUpdate();
            
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
          }
         
    }



    
    
}
