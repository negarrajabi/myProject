/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

/**
 *
 * @author negar
 */
public class mainPage extends JPanel {
    JFrame mainFrame;

    JMenu infoBtn,reportsBtn,balanceBtn,chequeBtn,toolsBtn,systemBtn,infoManagementBtn,helpBtn;

    JTabbedPane tp;
    JPanel p1;
    JPanel p2;
    JTabbedPane tpp;
    String username;
    String date;
    JMenuItem i1,i2,i3,i4;
    JMenuItem r1,r2,r3,r4,r5,r6,r7,r8,r9;
    JMenuItem b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
    JMenuItem c1,c2,c3;
    JMenuItem t1,t2,t3,t4,t5,t6,t7,t8,t9;
    JMenuItem s1,s2,s3,s4,s5,s6,s7,s8;
    JMenuItem im1,im2,im3,im4;
    JMenuItem h1;
    JMenuBar bar;
    JMenuBar bar2;
    JMenu m1,m2,m3,m4,m5;



    public mainPage(String username,String date){
        this.username=username;
        this.date=date;
        mainFrame=new JFrame();
        tp=new JTabbedPane();
        p1=new JPanel();
        p2=new JPanel();
        JPanel p3=new JPanel();
        bar = new JMenuBar();
        tp.setBounds(0,20,400,350);
        tp.add("بنجره ها",p1);
        tp.add("مشخصات سرور",p2);
        mainFrame.add(tp);
        tpp=new JTabbedPane();
        tpp.setBounds(0,350,400,250);
        tpp.add(p3);
        JLabel nameLabel=new JLabel();
        p3.setLayout(null);
        nameLabel.setText("نام کاربری:   "+username);
        JLabel dateLabel=new JLabel();
        dateLabel.setText("زمان ورود:   "+date);
        nameLabel.setBounds(100,50,300,20);
        dateLabel.setBounds(100,100,300,20);
        p3.add(nameLabel);
        p3.add(dateLabel);
        mainFrame.add(tpp);
        bar2=new JMenuBar();

        infoBtn=new JMenu("اطلاعات");
        reportsBtn=new JMenu("گزارش ها و گردش ها");
        balanceBtn=new JMenu("ترازها");
        chequeBtn=new JMenu("چک");
        toolsBtn=new JMenu("ابزار");
        systemBtn=new JMenu("سیستم");
        infoManagementBtn=new JMenu("مدیریت اطلاعات");
        helpBtn=new JMenu("راهنما");
        m1=new JMenu("+");
        m2=new JMenu();
        m3=new JMenu();
        m4=new JMenu();
        m5=new JMenu();
        
        bar2.add(m1);
        bar2.add(m2);
        bar2.add(m3);
        bar2.add(m4);
        bar2.add(m5);
        


        bar.add(helpBtn);
        bar.add(infoManagementBtn);
        bar.add(systemBtn);
        bar.add(toolsBtn);
        bar.add(chequeBtn);
        bar.add(balanceBtn);
        bar.add(reportsBtn);
        bar.add(infoBtn);
        
        

        JLabel serverName=new JLabel();
        serverName.setText("");



        //info menu items
        i1=new JMenuItem("اطلاعات بایه");
        i2=new JMenuItem("فهرست اسناد حسابداری");
        i3=new JMenuItem("تدوین سند حسابداری جدید");
        i4=new JMenuItem("فهرست بیلان های طراحی شده");

        infoBtn.add(i1);
        infoBtn.addSeparator();
        infoBtn.add(i2);
        infoBtn.add(i3);
        infoBtn.addSeparator();
        infoBtn.add(i4);


        //report menu items
        r1=new JMenuItem("گردش یک حساب");
        r2=new JMenuItem("اسناد ثبت شده");
        r3=new JMenuItem("گردش اشخاص");
        r4=new JMenuItem("گردش مرکز هزینه");
        r5=new JMenuItem("ادغام اسناد");
        r6=new JMenuItem("دفاتر قانونی");
        r7=new JMenuItem("دفتر روزنامه");
        r8=new JMenuItem("گردش سالیانه حساب ها");
        r9=new JMenuItem("نفکیک عملیات حساب به نوع سند");


        reportsBtn.add(r1);
        reportsBtn.add(r2);
        reportsBtn.addSeparator();
        reportsBtn.add(r3);
        reportsBtn.add(r4);
        reportsBtn.addSeparator();
        reportsBtn.add(r5);
        reportsBtn.addSeparator();
        reportsBtn.add(r6);
        reportsBtn.add(r7);
        reportsBtn.add(r8);
        reportsBtn.addSeparator();
        reportsBtn.add(r9);


        //balance menu items
        b1=new JMenuItem("تراز آزمایشی چهار ستونی");
        b2=new JMenuItem("تراز آزمایشی شش ستونی");
        b3=new JMenuItem("تراز آزمایشی هشت ستونی");
        b4=new JMenuItem("تراز آزمایشی چهار ستونی یک حساب");
        b5=new JMenuItem("تراز آزمایشی شش ستونی یک حساب");
        b6=new JMenuItem("تراز مرکز هزینه");
        b7=new JMenuItem("تراز اشخاص");
        b8=new JMenuItem("صورت سود و زیان");
        b9=new JMenuItem("مانده سود و زیان");
        b10=new JMenuItem("گزارش صورت تحلیلی بیلان");

        balanceBtn.add(b1);
        balanceBtn.add(b2);
        balanceBtn.add(b3);
        balanceBtn.addSeparator();
        balanceBtn.add(b4);
        balanceBtn.add(b5);
        balanceBtn.addSeparator();
        balanceBtn.add(b6);
        balanceBtn.add(b7);
        balanceBtn.addSeparator();
        balanceBtn.add(b8);
        balanceBtn.add(b9);
        balanceBtn.addSeparator();
        balanceBtn.add(b10);


        //cheque menu items
        c1=new JMenuItem("گزارش سررسید چک ها");
        c2=new JMenuItem("تراز سررسید چک ها");
        c3=new JMenuItem("گزارش شماره چک های مشابه");

        chequeBtn.add(c1);
        chequeBtn.add(c2);
        chequeBtn.addSeparator();
        chequeBtn.add(c3);



        //tools menu items
        t1=new JMenuItem("تغییر مشخصات چک");
        t2=new JMenuItem("دايمی کردن اسناد حسابداری");
        t3=new JMenuItem("از دایم خارج کردن اسناد حسابداری");
        t4=new JMenuItem("مرتب سازی شماره اسناد");
        t5=new JMenuItem("خطایابی اسناد حسابداری");
        t6=new JMenuItem("ادغام روزانه استاد");
        t7=new JMenuItem("ثبت سند افتتاحیه");
        t8=new JMenuItem("ثبت سند اختتامیه");
        t9=new JMenuItem("شارژ ماهیانه");

        toolsBtn.add(t1);
        toolsBtn.add(t2);
        toolsBtn.add(t3);
        toolsBtn.addSeparator();
        toolsBtn.add(t4);
        toolsBtn.add(t5);
        toolsBtn.add(t6);
        toolsBtn.addSeparator();
        toolsBtn.add(t7);
        toolsBtn.add(t8);
        toolsBtn.addSeparator();
        toolsBtn.add(t9);


        //system menu item
        s1=new JMenuItem("فهرست کاربران برنامه");
        s2=new JMenuItem("تغییر کلمه عبور");
        s3=new JMenuItem("تنظیم فونت برنامه");
        s4=new JMenuItem("تقویم");
        s5=new JMenuItem("تنظیمات(کاربر فعلی)");
        s6=new JMenuItem("ایجاد فایل صادره");
        s7=new JMenuItem("فراخوانی یک فایل صادره");
        s8=new JMenuItem("خروج");

        systemBtn.add(s1);
        systemBtn.add(s2);
        systemBtn.addSeparator();
        systemBtn.add(s3);
        systemBtn.add(s4);
        systemBtn.addSeparator();
        systemBtn.add(s5);
        systemBtn.add(s6);
        systemBtn.add(s7);
        systemBtn.addSeparator();
        systemBtn.add(s8);



        //info management menu items
        im1=new JMenuItem("مدیریت گروه شرکت های معرفی شده");
        im2=new JMenuItem("مدیریت سال های مالی");
        im3=new JMenuItem("بازسازی اطلاعات");
        im4=new JMenuItem("بشتیبان گیری و بازیابی بشتیبان");

        infoManagementBtn.add(im1);
        infoManagementBtn.add(im2);
        infoManagementBtn.addSeparator();
        infoManagementBtn.add(im3);
        infoManagementBtn.addSeparator();
        infoManagementBtn.add(im4);


        //help menu items
        h1=new JMenuItem("درباره برنامه");
        helpBtn.add(h1);










        mainFrame.setTitle("سیتم حسابداری ترازنگار");
        mainFrame.setSize(1000,600);

        bar.setBounds(400,0,600,40);
        bar2.setBounds(400,40,600,40);
        mainFrame.setLayout(null);
        mainFrame.setVisible(true);

        mainFrame.add(bar);
        mainFrame.add(bar2);
        
        m1.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("create new deed");
                NewDeed nd=new NewDeed();
            }
        });
        m1.addMenuListener(new MenuListener() {

            @Override
            public void menuSelected(MenuEvent me) {
                System.out.println("create new deed");
                NewDeed nd=new NewDeed();
            }

            @Override
            public void menuDeselected(MenuEvent me) {
               // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void menuCanceled(MenuEvent me) {
               // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        i1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                infoPage inf=new infoPage();
            }

           
        });

    }

   
    
}
