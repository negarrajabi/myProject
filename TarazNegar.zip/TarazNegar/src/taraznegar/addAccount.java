/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.Checkbox;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.AbstractButton;
import javax.swing.AbstractListModel;
import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author negar
 */
public class addAccount extends JFrame {
    JFrame addAccountFrame;
    String[] accountgroups;

    JPanel addAccountPane;
    acc addAcc;
    JLabel codekol,codemoein,code1,code2,code3,accname,accGp,attent;
    JTextField codekoltf,codemoeintf,code1tf,code2tf,code3tf,accnametf,accGptf,attenttf;
    JComboBox codekolcb,codemoeincb,code1cb,code2cb,code3cb,accGpcb;
    acc newAcc;
    String codekol1,codemoein1,ss,codam=null;
    String[] groups;
    int counter=0,i=0;
    public addAccount(){
        
        addAccountFrame=new JFrame();
        addAccountFrame.setTitle("تدوین یک حساب");

        newAcc=new acc();
        codekol=new JLabel("کد کل");
        codemoein=new JLabel("کد معین");
        code1=new JLabel("کد تفصیل ۱");
        code2=new JLabel("کد تفصیل ۲");
        code3=new JLabel("کد تفصیل ۳");
        accname=new JLabel("نام حساب");
        accGp=new JLabel("گروه حساب");
        attent=new JLabel("ملاحظات");
        codekol.setBounds(545, 20, 100, 20);
        addAccountFrame.add(codekol);
                codemoein.setBounds(535, 50, 100, 20);
        addAccountFrame.add(codemoein);
                code1.setBounds(510, 80, 100, 20);
        addAccountFrame.add(code1);
                code2.setBounds(510, 110, 100, 20);
        addAccountFrame.add(code2);
                code3.setBounds(510, 140, 100, 20);
        addAccountFrame.add(code3);
                accname.setBounds(520, 180, 100, 20);
        addAccountFrame.add(accname);
                accGp.setBounds(515, 210, 100, 20);
        addAccountFrame.add(accGp);
                attent.setBounds(525, 320, 100, 20);
        addAccountFrame.add(attent);
        codekoltf=new JTextField();
        codekoltf.setBounds(400,20,80,20);
        addAccountFrame.add(codekoltf);
        
        codemoeintf=new JTextField();
        codemoeintf.setBounds(400,50,80,20);
        addAccountFrame.add(codemoeintf);
        
        code1tf=new JTextField();
        code1tf.setBounds(400,80,80,20);
        addAccountFrame.add(code1tf);
        
        code2tf=new JTextField();
        code2tf.setBounds(400,110,80,20);
        addAccountFrame.add(code2tf);
        
        code3tf=new JTextField();
        code3tf.setBounds(400,140,80,20);
        addAccountFrame.add(code3tf);
        
        accnametf=new JTextField();
        accnametf.setBounds(20,180,460,20);
        addAccountFrame.add(accnametf);
        
        
        
        accGptf=new JTextField();
        accGptf.setBounds(400,210,80,20);
        addAccountFrame.add(accGptf);
        
        codemoeincb=new JComboBox();
        codemoeincb.setBounds(20,50,378,20);
        addAccountFrame.add(codemoeincb);
        codemoeincb.setSelectedIndex(-1);
        
                    ArrayList arrayList = new ArrayList();
        try{
         Class.forName("com.mysql.jdbc.Driver");
            Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
            java.sql.Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from accountGps order by code");
        
            while(rs.next()){

                ss=rs.getString(2)+"-"+rs.getString(1);
                arrayList.add(ss);

            }
            con.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        ArrayListComboBoxModel model = new ArrayListComboBoxModel(arrayList);
        
        accGpcb=new JComboBox(model);
        accGpcb.setBounds(20,210,378,20);
        addAccountFrame.add(accGpcb);
        
        
        

        
                    ArrayList arrayList1 = new ArrayList();
        try{
         Class.forName("com.mysql.jdbc.Driver");
            Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
            java.sql.Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from myAccs where code like'___' order by code");
            
            while(rs.next())
                arrayList1.add(rs.getString(1)+ "-" + rs.getString(2));
            con.close();
            
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        
        ArrayListComboBoxModel codekolModel = new ArrayListComboBoxModel(arrayList1);
        
        
        
        codekolcb=new JComboBox(codekolModel);
        codekolcb.setBounds(20,20,378,20);
        addAccountFrame.add(codekolcb);
       
         codekolcb.addItemListener((ItemEvent event) -> {
             JComboBox comboBox = (JComboBox) event.getSource();
             Object item = event.getItem();
             String codesh=item.toString();
             String[] codes=codesh.split("-");
             codekol1=codes[0];
             codekoltf.setText( codes[0]);
             newAcc.code=codekoltf.getText();
             try{
                 Class.forName("com.mysql.jdbc.Driver");
                 Connection  con = DriverManager.getConnection(
                         "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                         "root", "1234");
                 java.sql.Statement stmt=con.createStatement();
                 String myrs="select accountGP from myAccs where code=\""+codekol1+"\"";
                 System.out.println(myrs);
                 ResultSet rs=stmt.executeQuery(myrs);
                 while(rs.next())
                     codam=rs.getString(1);
                 System.out.println(codam);
                 
                 con.close();
                 
             } catch (ClassNotFoundException | SQLException e) {
                 System.out.println(e);
             }   ArrayList arrayList2 = new ArrayList();
             try{
                 Class.forName("com.mysql.jdbc.Driver");
                 Connection  con = DriverManager.getConnection(
                         "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                         "root", "1234");
                 java.sql.Statement stmt=con.createStatement();
                 String myrs="select * from myAccs where code like\'" + codekol1 + "____\' order by code";
                 System.out.println(myrs);
                 ResultSet rs=stmt.executeQuery(myrs);
                 
                 String s=null,s1=null;
                 while(rs.next()){
                     s=rs.getString(2)+ "-" + rs.getString(1);
                     System.out.println(s);
                     String[] codes1=s.split("-");
                     arrayList2.add(codes1[2]+ "-" + codes1[0]);
                     
                     
                 }
                 String s2="select accountGP from myAccs where code=\""+codekol1+"\"";
                 System.out.println(s2);
                 ResultSet rs1=stmt.executeQuery(s2);
                 codam=rs1.getString(1);
                 System.out.println(codam);
                 con.close();
                 
             } catch (Exception e) {
                 System.out.println(e);
             }   try {
                 Class.forName("com.mysql.jdbc.Driver");
                 Connection  con = DriverManager.getConnection(
                         "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                         "root", "1234");
                 java.sql.Statement stmt=con.createStatement();
                 ResultSet rs=stmt.executeQuery("select code from accountGps order by code");
                 int i1 = 0;
                 while (rs.next()) {
                     if(codam.equals(rs.getString(1))){
                         
                         System.out.println(codam);
                         System.out.println("ine groupesh");
                    break;
                    
                     }   i1++;

                }
                 accGpcb.setSelectedIndex(i1);
                 accGpcb.setEnabled(false);
                accGptf.setEnabled(false);
                con.close();
             }catch (ClassNotFoundException | SQLException e) {
                 System.out.println(e);
             }   ArrayListComboBoxModel codemoeinModel = new ArrayListComboBoxModel(arrayList2);
            int i2 = 0;
            int k=arrayList2.size();
            while (i2 < k) {
                System.out.println(arrayList2.get(i2));
                codemoeincb.addItem(arrayList2.get(i2));
                i2++;
            }
                    codemoeincb.setSelectedIndex(-1);
                    codemoeintf.setText("");
        } // Listening if a new items of the combo box has been selected.
        );
         
         codemoeincb.addItemListener(new ItemListener() {
            // Listening if a new items of the combo box has been selected.
            public void itemStateChanged(ItemEvent event) {
                JComboBox comboBox = (JComboBox) event.getSource();
                Object item = event.getItem();
                String codesh=item.toString();
                String[] codes=codesh.split("-");
                codemoein1=codes[0];
                codemoeintf.setText( codes[0]);
                  ArrayList arrayList3 = new ArrayList();
                try{
         Class.forName("com.mysql.jdbc.Driver");
            Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
            java.sql.Statement stmt=con.createStatement();
            String myrs="select * from myAccs where code like\'" + codekol1 +"-"+codemoein1+ "____\' order by code";
            System.out.println(myrs);
            ResultSet rs=stmt.executeQuery(myrs);
            int counter = 0;
            String s,s1=null;
            while(rs.next()){
               // System.out.println(rs);
                s=rs.getString(2)+ "-" + rs.getString(1);
        
                System.out.println(s);
               String[] codes1=s.split("-");
               System.out.println(codes1[3]+ "-" + codes1[0]);
                arrayList3.add(codes1[3]+ "-" + codes1[0]);
            }
            con.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        ArrayListComboBoxModel code1Model = new ArrayListComboBoxModel(arrayList3);
        int i=0;
        int k=arrayList3.size();
        while(i<k){
            System.out.println(arrayList3.get(i));
            code1cb.addItem(arrayList3.get(i));
            i++;
        }
        code1cb.setSelectedIndex(-1);
        code1tf.setText("");
                }
            });
                

        code1cb=new JComboBox();
        code1cb.setBounds(20,80,378,20);
        addAccountFrame.add(code1cb);
        
        code2cb=new JComboBox();
        code2cb.setBounds(20,110,378,20);
        addAccountFrame.add(code2cb);
        
        code3cb=new JComboBox();
        code3cb.setBounds(20,140,378,20);
        addAccountFrame.add(code3cb);
        
      
        
                 accGpcb.addItemListener(new ItemListener() {
            // Listening if a new items of the combo box has been selected.
            public void itemStateChanged(ItemEvent event) {
                JComboBox comboBox = (JComboBox) event.getSource();
                Object item = event.getItem();
                String s=item.toString();
                String[] q=s.split("-");
                accGptf.setText( q[1]);
                newAcc.accountGP=accGptf.getText();
            }
        });
        
        
                 
        JLabel accType=new JLabel("نوع حساب:");
        accType.setBounds(510,250,100,20);
        addAccountFrame.add(accType);
        
        JRadioButton r1=new JRadioButton("موقت");    
        JRadioButton r2=new JRadioButton("دايم");    
        r1.setBounds(250,250,100,20);    
        r2.setBounds(360,250,100,20);    
        ButtonGroup bg=new ButtonGroup();    
        bg.add(r1);bg.add(r2);    
        addAccountFrame.add(r1);
        addAccountFrame.add(r2);
        
            ItemListener itemListener = new ItemListener() {
      String lastSelected;
      public void itemStateChanged(ItemEvent itemEvent) {
        AbstractButton aButton = (AbstractButton)itemEvent.getSource();
        int state = itemEvent.getStateChange();
        String label = aButton.getText();
        String msgStart;
        if (state == ItemEvent.SELECTED) {
         
        System.out.println( label);
        newAcc.accType=label;
        //newAcc.accType="f";
        }
      }
    };
        
    r1.addItemListener(itemListener);
    r2.addItemListener(itemListener);
        
        Checkbox checkbox1 = new Checkbox("در اسناد انتخاب مرکز هزینه الزامی است");  
        checkbox1.setBounds(200,290, 300,20);  
        addAccountFrame.add(checkbox1);
        
        attenttf=new JTextField();
        attenttf.setBounds(20, 320, 480, 20);
        addAccountFrame.add(attenttf);
        
        
        JLabel accMatter=new JLabel("ماهیت حساب:");
        accMatter.setBounds(495, 360, 100, 20);
        addAccountFrame.add(accMatter);
        
        
        JRadioButton r3=new JRadioButton("بدهکار/بستانکار");    
        JRadioButton r4=new JRadioButton("بدهکار");    
        JRadioButton r5=new JRadioButton("بستانکار");    
        r4.setBounds(250,360,100,20);    
        r3.setBounds(360,360,150,20);    
        r5.setBounds(140,360,100,20);    
        ButtonGroup bg1=new ButtonGroup();    
        bg1.add(r3);bg1.add(r4);bg1.add(r5);    
        addAccountFrame.add(r3);
        addAccountFrame.add(r4);
        addAccountFrame.add(r5);
        
                    ItemListener itemListener1 = new ItemListener() {
      String lastSelected;
      public void itemStateChanged(ItemEvent itemEvent) {
        AbstractButton aButton = (AbstractButton)itemEvent.getSource();
        int state = itemEvent.getStateChange();
        String label = aButton.getText();
        if (state == ItemEvent.SELECTED) {
         
        System.out.println( label);
        newAcc.accMatter=label;
        //newAcc.accMatter="c";
        }
      }
    };
        
    r3.addItemListener(itemListener1);
    r4.addItemListener(itemListener1);
    r5.addItemListener(itemListener1);
        
        JLabel accStatus=new JLabel("وضعیت حساب:");
        accStatus.setBounds(490, 390, 100, 20);
        addAccountFrame.add(accStatus);

        
        JRadioButton r6=new JRadioButton("هیچکدام");    
        JRadioButton r7=new JRadioButton("درآمد");    
        JRadioButton r8=new JRadioButton("هزینه");    
        r7.setBounds(250,390,100,20);    
        r6.setBounds(360,390,100,20);    
        r8.setBounds(140,390,100,20);    
        ButtonGroup bg2=new ButtonGroup();    
        bg2.add(r6);bg2.add(r7);bg2.add(r8);    
        addAccountFrame.add(r6);
        addAccountFrame.add(r7);
        addAccountFrame.add(r8);
        
      ItemListener itemListener2 = new ItemListener() {
      String lastSelected;
      @Override
      public void itemStateChanged(ItemEvent itemEvent) {
        AbstractButton aButton = (AbstractButton)itemEvent.getSource();
        int state = itemEvent.getStateChange();
        String label = aButton.getText();
        if (state == ItemEvent.SELECTED) {
         
        System.out.println( label);
        newAcc.accStatus=label;
        //newAcc.accStatus="b";
        }
      }
    };
        
    r6.addItemListener(itemListener2);
    r7.addItemListener(itemListener2);
    r8.addItemListener(itemListener2);
        
        JLabel costBenefit=new JLabel("وضعیت حساب در سود و زیان");
        costBenefit.setBounds(400, 420, 200, 20);
        addAccountFrame.add(costBenefit);
        
        String cost[]={"اقلام سود و زیانی میباشد","اقلام سود و زیانی نمیباشد"};     
        JComboBox costBenefitcb=new JComboBox(cost);
        costBenefitcb.setBounds(20,420,378,20);
        addAccountFrame.add(costBenefitcb);
        
        
         costBenefitcb.addItemListener((ItemEvent event) -> {
             JComboBox comboBox = (JComboBox) event.getSource();
             Object item = event.getItem();
             newAcc.items=item.toString();
             // newAcc.items="a";
        } // Listening if a new items of the combo box has been selected.
        );
         
        JLabel center=new JLabel("مرکز هزینه:");
        center.setBounds(500, 450, 100, 20);
        addAccountFrame.add(center);
        
        JTextField centertf=new JTextField();
        centertf.setBounds(400,450,80,20);
        addAccountFrame.add(centertf);
        
        JComboBox centercb=new JComboBox(model);
        centercb.setBounds(20,450,378,20);
        addAccountFrame.add(centercb);
        
                
                
         centercb.addItemListener((ItemEvent event) -> {
             JComboBox comboBox = (JComboBox) event.getSource();
             Object item = event.getItem();
             centertf.setText( item.toString());
             
             newAcc.center=centertf.getText();
        } // Listening if a new items of the combo box has been selected.
        );
         

        
        JLabel project=new JLabel("پروژه:");
        project.setBounds(540, 480, 100, 20);
        addAccountFrame.add(project);
        
         JTextField projecttf=new JTextField();
        projecttf.setBounds(400,480,80,20);
        addAccountFrame.add(projecttf);
        
        JComboBox projectcb=new JComboBox(model);
        projectcb.setBounds(20,480,378,20);
        addAccountFrame.add(projectcb);
        
        
        JLabel currrency=new JLabel("ارز:");
        currrency.setBounds(540, 510, 100, 20);
        addAccountFrame.add(currrency);
        
         JTextField currrencytf=new JTextField();
        currrencytf.setBounds(400,510,80,20);
        addAccountFrame.add(currrencytf);
        
        JComboBox currrencycb=new JComboBox(model);
        currrencycb.setBounds(20,510,378,20);
        addAccountFrame.add(currrencycb);
  
        
        JButton exitBtn=new JButton("خروج");
        exitBtn.setBounds(20,550,100,30);
        addAccountFrame.add(exitBtn);

            exitBtn.addActionListener((ActionEvent actionEvent) -> {
                newAcc.code=null;
                addAccountFrame.dispatchEvent(new WindowEvent(addAccountFrame, WindowEvent.WINDOW_CLOSING));
        });
        
        JButton saveBtn=new JButton("ذخیره");
        saveBtn.setBounds(150,550,100,30);
        addAccountFrame.add(saveBtn);

        
                    saveBtn.addActionListener((ActionEvent actionEvent) -> {
                        newAcc.code=codekoltf.getText();
                        System.out.println("moein");
                        System.out.println(codemoeintf.getText());
                        if(!codemoeintf.getText().trim().equals("")){
                            System.out.println("here");
                            newAcc.code=newAcc.code + "-" + codemoeintf.getText();
                            if(!code1tf.getText().trim().equals("") ){
                                newAcc.code=newAcc.code + "-" + code1tf.getText();
                                if(!code2tf.getText().trim().equals("") ){
                                    newAcc.code=newAcc.code + "-" + code2tf.getText();
                                    if(!code3tf.getText().trim().equals("") ){
                                        newAcc.code=newAcc.code + "-" + code3tf.getText();
                                    }
                                }
                            }
                        }
                        newAcc.name=accnametf.getText();
                        newAcc.attentions=attenttf.getText();
                        accounts.addRows(newAcc);
                        
                        addAccountFrame.dispatchEvent(new WindowEvent(addAccountFrame, WindowEvent.WINDOW_CLOSING));
        });
        //addAccountFrame.getContentPane().add(new JFrmaeGraphics());
        addAccountFrame.getContentPane().add(new MyCanvas());
        addAccountFrame.setBounds(500,200,600,600);
        addAccountFrame.setLayout(null);
        addAccountFrame.setVisible(true);
        
        

        
    }
   


    
}
class ArrayListComboBoxModel extends AbstractListModel implements ComboBoxModel {
  private Object selectedItem;

  private ArrayList anArrayList;

  public ArrayListComboBoxModel(ArrayList arrayList) {
    anArrayList = arrayList;
  }

  public Object getSelectedItem() {
    return selectedItem;
  }

  public void setSelectedItem(Object newValue) {
    selectedItem = newValue;
  }

  public int getSize() {
    return anArrayList.size();
  }

  public Object getElementAt(int i) {
    return anArrayList.get(i);
  }

}
class MyCanvas extends JComponent { 
  
    public void paint(Graphics g) 
    { 
  
        // draw and display the line 
        g.drawLine(10, 380, 100, 380); 
    } 
} 