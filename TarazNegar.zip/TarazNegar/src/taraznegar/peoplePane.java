/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author negar
 */
public class peoplePane {
    
JPanel accPane;
    JTabbedPane tp;
    JTable table;
    JButton addBtn;
    JButton deleteBtn;
    
    
    private static String[] header = {"ملاحظات", "نام", "کد"};
    private DefaultTableModel dtm = new DefaultTableModel (null, header) {

        @Override
        public Class<?> getColumnClass(int col) {
            return getValueAt(0, col).getClass();
        }
    };
    public peoplePane()  {
         try {
                Class.forName("com.mysql.jdbc.Driver");
 Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
            java.sql.Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from people");
            while(rs.next())
                dtm.addRow(new Object[]{rs.getString(3),rs.getString(2),rs.getString(1)});
            con.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
        ImageIcon icon1 = new ImageIcon("/home/negar/Downloads/icon.png");
        Image img = icon1.getImage() ;  
        Image newimg = img.getScaledInstance( 5, 5,  java.awt.Image.SCALE_SMOOTH ) ;  
        icon1 = new ImageIcon( newimg );
        tp=new JTabbedPane();
        tp.setBounds(0, 0, 2000, 800);
        addBtn=new JButton(icon1);
        addBtn.setText("افزودن");
        deleteBtn=new JButton("delete");
        accPane=new JPanel();
        accPane.setLayout(null);
        accPane.add(tp);      
        table=new JTable(dtm);
    
        addBtn.setBounds(30,850,100,50);
        deleteBtn.setBounds(200,850,100,50);
        accPane.add(addBtn);
        accPane.add(deleteBtn);
        table.setBounds(50,50,200,300);
        JScrollPane sp=new JScrollPane(table);
        sp.setBounds(0, 50, 500, 500);
       
        addBtn.addActionListener(new ActionListener(){
             @Override
            public void actionPerformed(ActionEvent actionEvent) {
                 
                     addRow();
            }
        });
        deleteBtn.addActionListener(new ActionListener(){
             @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int i =table.getSelectedRow();
                String code=(String) dtm.getValueAt(i, 2);
                 System.out.println(code);
                dtm.removeRow(i);
                     try 
     {  
        Class.forName("com.mysql.jdbc.Driver");
         Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB", "root", "1234");

        PreparedStatement st = con.prepareStatement("DELETE FROM people WHERE code = " + code + ";");
        st.executeUpdate(); 
        con.close();
     }
     catch(Exception e)
     {
         System.out.println(e);
     }
            }
        });
       
       tp.add(sp);
       //tp.add(addBtn);
       
        
    }
    private void addRow()  {
          accGp ac=optionDialog();
          if(ac.code != null){
          dtm.addRow(new Object[]{
               ac.attentions,ac.name,ac.code
            });
          try {
                Class.forName("com.mysql.jdbc.Driver");
                 Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
           String insertSQL = "INSERT INTO people (code,name,attentions) VALUES (?, ?,?)";
           PreparedStatement preparedStatement = con.prepareStatement(insertSQL);
           preparedStatement.setString(1, ac.code);
           preparedStatement.setString(2, ac.name);
           preparedStatement.setString(3, ac.attentions);
           preparedStatement.executeUpdate();
            
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
          }
         
    }
    public accGp optionDialog(){
        Object[] options = {"ذخیره","خروج"};
         JPanel pane = new JPanel();
        pane.setLayout(new GridLayout(0, 2, 2, 2));

        JTextField codeField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField attentionField = new JTextField();

        pane.add(new JLabel("کد"));
        pane.add(codeField);

        pane.add(new JLabel("نام"));
        pane.add(nameField);
        
        pane.add(new JLabel("ملاحظات"));
        pane.add(attentionField);
        accGp ac=new accGp();
        int option = JOptionPane.showOptionDialog( accPane,pane, "Please fill all the fields",JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE,null,options,options[1]);
        //disable save button till fill the code box
        if (option == JOptionPane.YES_OPTION) {
            
             ac.code=codeField.getText();
             System.out.println(ac.code);
             ac.name=nameField.getText();
             ac.attentions=attentionField.getText();
            }

        return ac;
        }

    
    }
    

