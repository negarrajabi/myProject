/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.Box;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import jdk.internal.org.objectweb.asm.tree.analysis.Value;

/**
 *
 * @author negar
 */
public class NewDeed extends JPanel {
     JFrame deedFrame;

    JMenu m1,m2,m3;
    JMenuBar bar;
    
    JPanel p1,p2,p3,p4,p5,p6,p7;
    JTabbedPane tp1;
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8;
    JTextField t1,t2,t3,t4,t5;
    int counter=0;
    boolean flag=true;
    JButton b1,b2,b3,b4;
    JTabbedPane tpp;
    String username;
    String date;
   
    deeds newDeeds1,newDeeds2;
    
     private static String[] header = {"ردیف","کد حساب","نام حساب"," شرح بند"," بدهکار"," بستانکار", " چک"};
      static String[][] datas={{"۱","","","","","",""}};
      String[] newRow={"","","","","","",""};
      private static DefaultTableModel tm = new DefaultTableModel(datas, header);
        JTable table= new JTable(tm){
                @Override
         public boolean isCellEditable(int row, int column) {                
                 if(column == 0) return false;
                return true;
    };
        };
     static int row=0;

DefaultTableModel model = new DefaultTableModel() {
    @Override
    public void setValueAt(Object value,
            int rowIndex,
            int columnIndex) {
        super.setValueAt(value, rowIndex, columnIndex);
        table.setRowSelectionInterval(rowIndex, rowIndex);
        table.changeSelection(rowIndex, columnIndex + 1, false, false);
    }
};

    public NewDeed(){
        newDeeds1=new deeds();
       
        deedFrame=new JFrame();

        m1=new JMenu("عملیات");
        m2=new JMenu("امکانات");
        m3=new JMenu("ماشین حساب");
        
        bar=new JMenuBar();
        bar.add(Box.createHorizontalGlue()); 
        bar.add(m3);
        bar.add(m2);
        bar.add(m1);
        
        bar.setBounds(0, 0, 1400, 40);
        deedFrame.add(bar);
        
        tp1=new JTabbedPane();
        tp1.setBounds(0, 40, 1400, 150);
        p1=new JPanel();
        p1.setLayout(null);
        p2=new JPanel();
        tp1.add("مشخصات اصلی",p1);
        
        l1=new JLabel("شماره سند");
        l1.setBounds(1300,20,100,30);
        p1.add(l1);
        
        tf1=new JTextField("۰");
        tf1.setBounds(1180,20,100,30);
        p1.add(tf1);
        
        l2=new JLabel(" تاریخ سند");
        l2.setBounds(1080,20,100,30);
        p1.add(l2);
        
        tf2=new JTextField("۱۳۹۶/۰۹/۱۲");
        tf2.setBounds(950,20,100,30);
        p1.add(tf2);
        
        
        
        l3=new JLabel(" نوع سند");
        l3.setBounds(830,20,100,30);
        p1.add(l3);
        
        tf3=new JTextField("۰");
        tf3.setBounds(670,20,150,30);
        p1.add(tf3);
        
        l4=new JLabel(" بخش");
        l4.setBounds(550,20,100,30);
        p1.add(l4);
        
        tf4=new JTextField("۰");
        tf4.setBounds(400,20,100,30);
        p1.add(tf4);
        
        l5=new JLabel(" ملاحظات");
        l5.setBounds(1300,60,100,30);
        p1.add(l5);
        
        tf5=new JTextField("۰");
        tf5.setBounds(20,60,1260,30);
        p1.add(tf5);
        
        
        tp1.add("مشخصات عمومی",p2);
        p2.setLayout(null);
        l6=new JLabel(" تنظیم کننده");
        l6.setBounds(1300,60,100,30);
        p2.add(l6);
        
        tf6=new JTextField("۰");
        tf6.setBounds(1180,60,100,30);
        p2.add(tf6);
        
        l7=new JLabel(" تاریخ صدور سند");
        l7.setBounds(1300,20,100,30);
        p2.add(l7);
        
        tf7=new JTextField("۱۳۹۶/۰۹/۱۲");
        tf7.setBounds(1180,20,100,30);
        p2.add(tf7);
        
        
        
        l8=new JLabel("  تایید کننده");
        l8.setBounds(1060,60,100,30);
        p2.add(l8);
        
        tf8=new JTextField("۰");
        tf8.setBounds(900,60,150,30);
        p2.add(tf8);
        
        deedFrame.add(tp1);
        t1=new JTextField();
        t1.setBounds(60,2,200,26);
        
        
        t2=new JTextField();
        t2.setBounds(260,2,200,26);
        p3=new JPanel();
        p3.setBackground(Color.LIGHT_GRAY);
        p3.setLayout(null);
        p3.setBounds(0,190,1400,30);
        p3.add(t1);
        p3.add(t2);
        deedFrame.add(p3);

        p4=new JPanel();
        p4.setLayout(null);
        p4.setBounds(0,220,1400,330);
        
         table.setRowHeight(30);
         table.setCellSelectionEnabled(true);
         table.add(Box.createHorizontalGlue());
        JScrollPane sp=new JScrollPane(table);
        table.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

        table.getColumnModel().getColumn(0).setMaxWidth(40);
        table.getColumnModel().getColumn(1).setMaxWidth(200);
        table.getColumnModel().getColumn(2).setMaxWidth(200);
        table.getColumnModel().getColumn(3).setMaxWidth(500);
        table.getColumnModel().getColumn(4).setMaxWidth(200);
        table.getColumnModel().getColumn(5).setMaxWidth(200);
        table.getColumnModel().getColumn(6).setMaxWidth(60);
        

        
    KeyStroke tab = KeyStroke.getKeyStroke(KeyEvent.VK_TAB, 0);
    KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
    InputMap im = table.getInputMap(JTable.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    im.put(enter, im.get(tab));
        Action action = new AbstractAction()
{
    @SuppressWarnings("empty-statement")
    public void actionPerformed(ActionEvent e)
    {
        TableCellListener tcl = (TableCellListener)e.getSource();
        System.out.println(tcl.getRow());
        System.out.println(table.getRowCount());
        if(tcl.getRow()+1== table.getRowCount()){
            if(tcl.getColumn()==6){
                
                    
                    String[] MynewRow={Integer.toString(table.getRowCount()+1),"","","","","",""};
                    tm.addRow(MynewRow);
                }
            
        
        }
    }
};




         table.getDefaultEditor(String.class).addCellEditorListener(
                new CellEditorListener() {
  

            @Override
            public void editingStopped(ChangeEvent ce) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                System.out.println("stopped");
                
                 TableCellListener tcl = new TableCellListener(table, action);
            }
            

            @Override
            public void editingCanceled(ChangeEvent ce) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
                });
         
          table.addMouseListener(new java.awt.event.MouseAdapter()

            {   

        public void mouseClicked(java.awt.event.MouseEvent e)

        {

            row=table.rowAtPoint(e.getPoint());
            System.out.println(row);
            

            int col= table.columnAtPoint(e.getPoint());
            System.out.println(col);
            if(col==2 || col==1){
                //create a search pane
                SearchPane sp=new SearchPane();

            
            

            System.out.println(" Value in the cell clicked :"+ "" +table.getValueAt(row,col).toString());
            }
            if(col==6){
                 String[] MynewRow={Integer.toString(table.getRowCount()+1),"","","","","",""};
                    tm.addRow(MynewRow);
            }
        }

        });
      
        
        table.setBounds(0,40,1400,330);
        
        sp.setBounds(0,0,1400,330);
        p4.add(sp);
        deedFrame.add(p4);
        
        p5=new JPanel();
        p5.setBounds(0, 550, 1400, 250);
        deedFrame.add(p5);
        p5.setLayout(null);

        b1=new JButton("سابقه");
        b1.setBounds(1152,0,60,60);
        p5.add(b1);
        
        b2=new JButton("سابقه");
        b2.setBounds(1214,0,60,60);
        p5.add(b2);
        
        b3=new JButton("سابقه");
        b3.setBounds(1276,0,60,60);
        p5.add(b3);
        
        b4=new JButton("سابقه");
        b4.setBounds(1338,0,60,60);
        p5.add(b4);
        
                
        t3=new JTextField();
        t3.setBounds(60,2,200,30);
        
        
        t4=new JTextField();
        t4.setBounds(260,2,200,30);
        p5.add(t3);
        p5.add(t4);
        
               
        
        l9=new JLabel("جمع کل");
        l9.setBounds(500,0,100,30);
        p5.add(l9);
               
        
        l10=new JLabel(" مانده بد از بس");
        l10.setBounds(500,40,100,30);
        p5.add(l10);
        
        
        t5=new JTextField();
        t5.setBounds(60,40,400,30);
        p5.add(t5);        
        
        
        
        
        
        deedFrame.setTitle("ثبت سند حسابداری جدید");       
        deedFrame.setSize(1400,800);
        deedFrame.setLayout(null);
        deedFrame.setVisible(true);

       
    }
     static void addRows(String name,String code )  {
                tm.setValueAt(code, row, 1);
                tm.setValueAt(name, row, 2);
         
     }


    
}
