/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author negar
 */
class generalSettingPane {
     JPanel gsettingPane;
    JLabel startLabel,endLabel,startYearLabel,endYearLabel,startMounthLabel,endMounthLabel,closeLabel,openLabel,defaultLabel;
    JTextField openField,opendCodeField,closeField,closeCodeField;
    JComboBox defaultCombo,startYearCombo,startMounthCombo,endYearCombo,endMounthCombo;
    public generalSettingPane(){
        String[] mounths={"1","2","3","4","5","6","7","8","9","10","11","12"};
        String[] years={"1397","1396","1395","1395","1394","1393","1392","1391","1390"};
        startYearCombo=new JComboBox(years);
        endMounthCombo=new JComboBox(mounths);
        startMounthCombo=new JComboBox(mounths);
        endYearCombo=new JComboBox(years);
        openField=new JTextField();
        openField.setBounds(220,290,280,25);
        opendCodeField=new JTextField();
        opendCodeField.setBounds(100,290,100,25);
        closeField=new JTextField();
        closeField.setBounds(220,260,280,25);
        closeCodeField=new JTextField();
        closeCodeField.setBounds(100,260,100,25);

        gsettingPane=new JPanel();
        gsettingPane.setLayout(null);
        startLabel=new JLabel("تاریخ شروع سال مالی");
        endLabel=new JLabel("تاریخ خاتمه سال مالی");
        startYearLabel=new JLabel("سال");
        endYearLabel=new JLabel("سال");
        startMounthLabel=new JLabel("ماه");
        endMounthLabel=new JLabel("ماه");
        closeLabel=new JLabel("حسابی که در اختتامیه حساب های موقت با آن بسته می شود");
        openLabel=new JLabel("حسابی که در افتتاحیه حساب های دایمی با آن باز می شود");
        defaultLabel=new JLabel("بخش بیش فرض");
        endLabel.setBounds(150,150,200,30);
        startLabel.setBounds(450,150,200,30);
        endYearLabel.setBounds(120,190,50,20);
        startYearLabel.setBounds(420,190,50,20);
        endMounthLabel.setBounds(220,190,50,20);
        startMounthLabel.setBounds(520,190,50,20);
        closeLabel.setBounds(600,250,400,30);
        openLabel.setBounds(600,290,400,30);
        defaultLabel.setBounds(420,350,150,30);

        defaultCombo=new JComboBox();
        startMounthCombo.setBounds(520,220,50,25);
        startYearCombo.setBounds(420,220,70,25);
        endYearCombo.setBounds(120,220,70,25);
        endMounthCombo.setBounds(220,220,50,25);
        defaultCombo.setBounds(120,350,150,25);
        gsettingPane.add(opendCodeField);
        gsettingPane.add(openField);
        gsettingPane.add(closeCodeField);
        gsettingPane.add(closeField);
        gsettingPane.add(startMounthCombo);
        gsettingPane.add(startYearCombo);
        gsettingPane.add(endYearCombo);
        gsettingPane.add(endMounthCombo);
        gsettingPane.add(defaultCombo);
        gsettingPane.add(startLabel);
        gsettingPane.add(endLabel);
        gsettingPane.add(startYearLabel);
        gsettingPane.add(endYearLabel);
        gsettingPane.add(startMounthLabel);
        gsettingPane.add(endMounthLabel);
        gsettingPane.add(closeLabel);
        gsettingPane.add(openLabel);
        gsettingPane.add(defaultLabel);


    }
    
}
