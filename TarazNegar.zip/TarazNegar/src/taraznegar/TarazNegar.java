/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

/**
 *
 * @author negar
 */


public class TarazNegar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //addAccount addac=new addAccount();

        //addCenter addcen=new addCenter();

        loginPage login=new loginPage();

       // NewDeed newdeed=new NewDeed();
        // TODO code application logic here

        
    }
            
        
    
}
