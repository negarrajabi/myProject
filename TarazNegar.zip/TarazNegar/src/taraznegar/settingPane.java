/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/**
 *
 * @author negar
 */
public class settingPane {
      JPanel setPane;

    JPanel generalSettingBtn;
    JPanel recordingSettingBtn;
    JPanel codingSettingBtn;
    JTabbedPane tp;

    public  settingPane(){
        tp=new JTabbedPane();
        tp.setBounds(0,0,2000,1400);

        setPane=new JPanel();
        setPane.setLayout(null);




        setPane.add(tp);
        generalSettingBtn=new JPanel();
        recordingSettingBtn=new JPanel();
        codingSettingBtn=new JPanel();
        generalSettingPane gs=new generalSettingPane();

        tp.add("تنظیمات عمومی برنامه",gs.gsettingPane);
        recordingSettingPane rs=new recordingSettingPane();
        tp.add("تنظیمات ذخیره سازی اسناد",rs.recordPane);
        tp.add("تنظیمات کدینگ",codingSettingBtn);


    }
    
}
