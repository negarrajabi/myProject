/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

/**
 *
 * @author negar
 */
public class acc {
    String code,name,accountGP,center,accType,accMatter,accStatus,items,attentions;
    public acc(){
        
    }
}
