/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import javax.swing.*;

import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.table.TableModel;
 
public class SearchPane extends JFrame {
    ArrayList<searchAcc> sc=new ArrayList<searchAcc>();
    ArrayList<searchDeed> sd=new ArrayList<searchDeed>();
    searchAcc finalsearch;
    
    public JTextField searchable = new JTextField(30);
    
     public static String[] header = {"کد کل","کد معین","کد تفصیل ۱","کد تفصیل ۲","کد تفصیل ۳", "نام", "کد"};
    public DefaultTableModel dtm = new DefaultTableModel (null, header) {

        @Override
        public Class<?> getColumnClass(int col) {
            return getValueAt(0, col).getClass();
        }
    };
public JTable result= new JTable(dtm){
        
                @Override
         public boolean isCellEditable(int row, int column) {                
               
                return false;
    };
        };
    public JPanel panel = new JPanel();
    public JScrollPane scrollPane=new JScrollPane(result) ;
     private TableRowSorter<TableModel> rowSorter
            = new TableRowSorter<>(result.getModel());


 
    public SearchPane() throws HeadlessException {
        super("جست و جوی حساب");
        
        setBounds(550, 298, 600, 600);
        setResizable(true);
        addComponents();
        setTable();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
 
    public void addComponents() {
        panel.setLayout(null);
        searchable.setBounds(50,20,500,30);
        panel.add(searchable);
       // panel.add(searchB);
       
        scrollPane.setBounds(20,65,560,520);
        panel.add(scrollPane);
        add(panel);
    }
 
    public void setTable() {
        result.setRowSorter(rowSorter);
        searchable.getDocument().addDocumentListener(new DocumentListener(){
            

            @Override
            public void insertUpdate(DocumentEvent e) {
                
                String text = searchable.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                String text = searchable.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }



        });
        result.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
        @Override
        public void valueChanged(ListSelectionEvent event) {
            finalsearch=new searchAcc();
            finalsearch.code=result.getValueAt(result.getSelectedRow(), 6).toString();
            finalsearch.name=result.getValueAt(result.getSelectedRow(), 5).toString();
            NewDeed.addRows(finalsearch.name, finalsearch.code);
            setVisible(false);
         
        }

       
    });
         
        
        try {
                Class.forName("com.mysql.jdbc.Driver");
                 Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
            java.sql.Statement stmt=con.createStatement();
           
            ResultSet rs=stmt.executeQuery("select * from myAccs");
            while(rs.next()){
                searchAcc sc1=new searchAcc();
                
                sc1.code=rs.getString(1);
                sc1.name=rs.getString(2);
 
                
               sc.add(sc1);
                
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
       
        for (int i = 0; i < sc.size(); i++) {
            searchDeed sd1=new searchDeed();
           sd1=new searchDeed();
           sd1.code=sc.get(i).code;
           sd1.name=sc.get(i).name;

           if(sd1.code.length()==3){
               sd1.t1=" ";
               sd1.t2=" ";
               sd1.t3=" ";
               sd1.moein="";
               sd1.kol=sc.get(i).name;
               
           }
               if(sd1.code.length()==7){
               sd1.t1="";
               sd1.t2="";
               sd1.t3="";
               sd1.moein=sc.get(i).name;
                   for (int j = 0; j < sc.size(); j++) {
                     if(sc.get(j).code.endsWith(sd1.code.substring(0, 3))){
                           sd1.kol=sc.get(j).name;
                           break;
                       }
                       
                   }
               
           }
               if(sd1.code.length()==11){
               sd1.t1=sc.get(i).name;
               sd1.t2="";
               sd1.t3="";
               for (int j = 0; j < sc.size(); j++) {
                       if(sc.get(j).code.equals(sd1.code.substring(0, 7))){
                           sd1.moein=sc.get(j).name;
                           break;
                       }
                       
                   }
                   for (int j = 0; j < sc.size(); j++) {
                       if(sc.get(j).code.equals(sd1.code.substring(0, 3))){
                           sd1.kol=sc.get(j).name;
                           break;
                       }
                       
                   }
               
           }
           sd.add(sd1);
           dtm.addRow(new Object[]{sd1.kol,sd1.moein,sd1.t1,sd1.t2,sd1.t3,sd1.name,sd1.code});
           //dtm.addRow(new Object[]{sd1.code,sd1.name,sd1.t1,sd1.t2,sd1.t3,sd1.moein,sd1.kol});
            
        }
       
    }
}
