/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.Graphics;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author negar
 */
class recordingSettingPane  {
     public void paintComponent(Graphics g) {
        g.drawLine(0,0, 500,500); 
        g.drawLine(500,0, 0,500); 
    }
    JPanel recordPane;
    JLabel label1;
    JButton btn1,btn2,btn3,btn4;
    JCheckBox box1,box2;
    public recordingSettingPane(){
        recordPane=new JPanel();
        recordPane.setLayout(null);
        btn1=new JButton("مشخصات اضافی در اشخاص");
        btn2=new JButton("مشخصات اضافی در مراکز هزینه");
        btn3=new JButton("مشخصات اضافی در اسناد");
        btn4=new JButton("مشخصات اضافی در بند های اسناد");
        box1=new JCheckBox("کنترل توالی تاریخ اسناد");
        box2=new JCheckBox("کنترل بشت سرهم بودن شماره اسناد");
        label1=new JLabel("تنظیمات ذخیره سازی اسناد");
        label1.setBounds(350,50,200,25);
        box1.setBounds(100,100,200,25);
        box2.setBounds(100,120,300,25);//channge this
        btn1.setBounds(150,300,300,25);
        btn2.setBounds(150,325,300,25);
        btn3.setBounds(150,350,300,25);
        btn4.setBounds(150,375,300,25);
        recordPane.add(box1);
        recordPane.add(box2);
        recordPane.add(btn1);
        recordPane.add(btn2);
        recordPane.add(btn3);
        recordPane.add(btn4);
        recordPane.add(label1);

    }
    
}
