/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;

/**
 *
 * @author negar
 */
public class infoPage extends JPanel{
     JToolBar bar1;

    JFrame infoFrame;
    JTabbedPane tp;
    public infoPage() {

        tp=new JTabbedPane();
        tp.setBounds(0,30,1500,30);
        infoFrame=new JFrame("اطلاعات بایه");
        infoFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        infoFrame.setUndecorated(true);
        infoFrame.setLayout(null);
        infoFrame.setVisible(true);
        bar1=new JToolBar();

        bar1.setBounds(0,0,2000,30);

        JButton processBtn=new JButton("عملیات");
        JButton columnsBtn=new JButton("ستونهای چدول");
        JButton searchBtn=new JButton("جستجو");
        JPanel acountGpBtn=new JPanel();
        JPanel acountsBtn=new JPanel();
        JPanel costTypeBtn=new JPanel();
        JPanel costBtn=new JPanel();
        JPanel projectBtn=new JPanel();
        JPanel exchangeBtn=new JPanel();
        JPanel deedBtn=new JPanel();
        JPanel chequeBtn=new JPanel();
        JPanel peopleBtn=new JPanel();
        JPanel ecxelBtn=new JPanel();
        JPanel partBtn=new JPanel();


        bar1.add(processBtn);
        bar1.add(columnsBtn);
        bar1.add(searchBtn);
        AccountGpPane acc=new AccountGpPane(); 
        tp.add("گروه حساب",acc.accPane);
        accounts account=new accounts(); 
        tp.add("حساب ها",account.accPane);
        centerTypePane ctp=new centerTypePane();
        tp.add("نوع مرکزهزینه",ctp.accPane);
        center ct=new center();
        tp.add("مرکز هزینه",ct.accPane);
        projectPane pro=new projectPane();
        tp.add("بروژه",pro.accPane);
        tp.add("ارز",exchangeBtn);
        deedPane deed=new deedPane();
        tp.add("نوع سند",deed.accPane);
        tp.add("وضعیت چک",chequeBtn);
        peoplePane people=new peoplePane();
        tp.add("اشخاص",people.accPane);
        tp.add("فراخوانی از اکسل",ecxelBtn);
        partsPane part=new partsPane();
        tp.add("بخش",part.accPane);
        settingPane set=new settingPane();
        tp.add("تنظیمات برنامه",set.setPane);
        tp.setBounds(0,30,2000,1450);
        infoFrame.add(bar1);
        infoFrame.add(tp);



    }

    
}
