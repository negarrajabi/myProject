/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.Checkbox;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author negar
 */
public class addCenter extends JFrame{
    JLabel code,name,centertype;
    JTextField code1,code2,code3,nametf;
    Checkbox denied,penalty;
    JFrame addCenterFrame;
    centeral newCenter;
    public addCenter(){
        newCenter=new centeral();
        addCenterFrame=new JFrame();
        addCenterFrame.setTitle("تدوین یک مرکزهزینه");
        
        code=new JLabel("کد");
        code.setBounds(550,20,50,20);
        addCenterFrame.add(code);
        
        code1=new JTextField();
        code1.setBounds(250,20,60,20);
        addCenterFrame.add(code1);
        
        code2=new JTextField();
        code2.setBounds(320,20,60,20);
        addCenterFrame.add(code2);
        
        code3=new JTextField();
        code3.setBounds(390,20,60,20);
        addCenterFrame.add(code3);
        
        name=new JLabel("نام");
        name.setBounds(550,50,50,20);
        addCenterFrame.add(name);
        
        nametf=new JTextField();
        nametf.setBounds(20,50,430,20);
        addCenterFrame.add(nametf);

                

        centertype=new JLabel("نوع مرکز هزینه");
        centertype.setBounds(485,80,100,20);
        addCenterFrame.add(centertype);
                   
        ArrayList arrayList = new ArrayList();

        
        try{
         Class.forName("com.mysql.jdbc.Driver");
            Connection  con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB?useUnicode=true&characterEncoding=utf-8",
                    "root", "1234");
            java.sql.Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from cenetrType");
            int counter = 0;
            while(rs.next())
              
                arrayList.add(rs.getString(2));
            con.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        ArrayListComboBoxModel model = new ArrayListComboBoxModel(arrayList);
        JComboBox centercb=new JComboBox(model);
        centercb.setBounds(260,80,180,20);
        addCenterFrame.add(centercb);
        
                 centercb.addItemListener(new ItemListener() {
            // Listening if a new items of the combo box has been selected.
            public void itemStateChanged(ItemEvent event) {
                JComboBox comboBox = (JComboBox) event.getSource();
                Object item = event.getItem();
                newCenter.centertype=item.toString();
            }
        });
        

                 
        denied = new Checkbox("این مرکز مسدود است");
        denied.setBounds(20, 80, 200, 20);
        addCenterFrame.add(denied);
        
        denied.addItemListener(new ItemListener() {
            // Listening if a new items of the combo box has been selected.
        public void itemStateChanged(ItemEvent event) {
               // Checkbox cb = (Checkbox) event.getSource();
               System.out.println("change");
            newCenter.denied=event.getStateChange()==1;
            System.out.println(event.getStateChange()==1);
                
            }
        });
        
        
        penalty = new Checkbox("برای این مرکز جریمه محاسبه نشود");
        penalty.setBounds(350, 130, 250, 20);
        addCenterFrame.add(penalty);
        
        
        String finalCode = null;
        if(code1.getText() != null){
            finalCode=code1.getText();
            if(code2.getText() != null){
                finalCode=finalCode + "-" + code2.getText();
                
            }
            
            if(code3.getText() != null){
                finalCode=finalCode + "-" + code3.getText();
                
            }
            
        }
        newCenter.code=finalCode;

        JButton exitBtn=new JButton("خروج");
        exitBtn.setBounds(20,120,100,30);
        addCenterFrame.add(exitBtn);

            exitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                newCenter.code=null;
                addCenterFrame.dispatchEvent(new WindowEvent(addCenterFrame, WindowEvent.WINDOW_CLOSING));
            }
        });

        JButton saveBtn=new JButton("ذخیره");
        saveBtn.setBounds(150,120,100,30);
        addCenterFrame.add(saveBtn);
        
                    saveBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                newCenter.name=nametf.getText().toString();
                
                center.addRows(newCenter);
                
                addCenterFrame.dispatchEvent(new WindowEvent(addCenterFrame, WindowEvent.WINDOW_CLOSING));
                
            }
        });
        addCenterFrame.getContentPane().add(new MyCanvas());
        addCenterFrame.setBounds(500,200,600,170);
        addCenterFrame.setLayout(null);
        addCenterFrame.setVisible(true);   
    }


    
    
    
}
