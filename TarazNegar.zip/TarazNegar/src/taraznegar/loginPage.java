/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taraznegar;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author negar
 */
public class loginPage extends JPanel {
        JFrame loginFrame;
    JLabel userlabel;
    JLabel passLabel;
    JTextField userField;
    JPasswordField passField;
    JButton loginBtn;
    JButton exitBtn;
    String username,date;
    public loginPage() {


        userField=new JTextField();
        passField=new JPasswordField();
        loginFrame =new JFrame();
        loginBtn=new JButton();
        loginBtn.setText("ورود");
        exitBtn=new JButton();
        exitBtn.setText("خروج");
        loginFrame.setTitle("سیستم حسابداری ترازنگار");
        userlabel=new JLabel( );
        passLabel=new JLabel( );
        userlabel.setText("نام کاربری");
        passLabel.setText("رمز عبوز");

        passField.setBounds(200,390,120,20);
        userField.setBounds(200,350,120,20);
        userlabel.setBounds(400,350,100,20);
        passLabel.setBounds(400,390,100,20);
        loginBtn.setBounds(300,450,100,20);
        exitBtn.setBounds(100,450,100,20);
        loginFrame.add(userlabel);
        loginFrame.add(userField);
        loginFrame.add(passLabel);
        loginFrame.add(passField);
        loginFrame.add(loginBtn);
        loginFrame.add(exitBtn);
       
        loginFrame.setLayout(null);
        loginFrame.setSize(500,500);
        loginFrame.setVisible(true);
        loginFrame.getContentPane().setBackground( Color.WHITE );
        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //if user and pass == true and logged in we have this
                String timeStamp = new SimpleDateFormat("yyyy/MM/dd_HH:mm:ss").format(Calendar.getInstance().getTime());
               //mainPage mp=new mainPage(userField.getText(),timeStamp);

                loginFrame.dispatchEvent(new WindowEvent(loginFrame, WindowEvent.WINDOW_CLOSING));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/TarazNegarDB", "root", "1234");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from logDB");
            System.out.println(userField.getText());
                System.out.println(passField.getText());
            while(rs.next()){
                System.out.println(rs.getString(1));
                System.out.println(rs.getInt(2));
                if(userField.getText().equals(rs.getString(1))){
                    System.out.println("id ok");
                    if(passField.getText().equals(rs.getString(2))){
                        //open
                        System.out.println("here you are?");
                        System.out.println(userField.getText());
                        System.out.println(timeStamp);
                        mainPage mp=new mainPage(userField.getText(),timeStamp);
                         break;
                         //error for wrong id
                    }
                }
                
            }
            con.close();

        }
        catch(Exception e){
            System.out.println(e);
        }
            }

        });
        exitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                loginFrame.dispatchEvent(new WindowEvent(loginFrame, WindowEvent.WINDOW_CLOSING));
            }
        });

    }
    
}
